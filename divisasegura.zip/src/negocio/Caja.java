package negocio;

public class Caja {
    private static final String[] DIVISAS = {"COP", "USD", "EUR", "MXN", "GBP"};
    private double[] saldosIniciales;
    private double[] saldos;

    public Caja() {
        saldosIniciales = new double[5];
        saldos = new double[5];
    }

    public Caja(double cop, double usd, double eur, double mxn, double gbp) {
        saldosIniciales = new double[] {cop, usd, eur, mxn, gbp};
        saldos = new double[] {cop, usd, eur, mxn, gbp};
    }

    private int buscarPosicion(String divisa) {
        for (int i = 0; i < DIVISAS.length; i++) {
            if (DIVISAS[i].equalsIgnoreCase(divisa)) {
                return i;
            }
        }
        return -1;
    }

    public double consultarSaldo(String divisa) {
        int posicion = buscarPosicion(divisa);
        if (posicion == -1) {
            throw new IllegalArgumentException("Divisa no reconocida: " + divisa);
        }
        return saldos[posicion];
    }

    // El monto puede ser positivo (entra dinero) o negativo (sale dinero).
    public void actualizarSaldo(String divisa, double variacion) {
        int posicion = buscarPosicion(divisa);
        if (posicion == -1) {
            throw new IllegalArgumentException("Divisa no reconocida: " + divisa);
        }
        if (saldos[posicion] + variacion < 0) {
            throw new IllegalArgumentException("Saldo insuficiente en " + divisa);
        }
        saldos[posicion] += variacion;
    }

    // Revierte los dos movimientos que produjo un cambio de divisa:
    // resta lo que el cliente entregó y devuelve lo que recibió.
    public void restituir(String divisaOrigen, String divisaDestino,
                          double montoOrigen, double montoDestino) {
        int posicionOrigen = buscarPosicion(divisaOrigen);
        int posicionDestino = buscarPosicion(divisaDestino);

        if (posicionOrigen == -1 || posicionDestino == -1) {
            throw new IllegalArgumentException("Divisa no reconocida.");
        }

        if (saldos[posicionOrigen] - montoOrigen < 0) {
            throw new IllegalArgumentException(
                    "No es posible restituir: saldo insuficiente en " + divisaOrigen);
        }

        saldos[posicionOrigen] -= montoOrigen;
        saldos[posicionDestino] += montoDestino;
    }

    public double diferenciaSaldo(String divisa) {
        int posicion = buscarPosicion(divisa);
        if (posicion == -1) {
            throw new IllegalArgumentException("Divisa no reconocida: " + divisa);
        }
        return saldos[posicion] - saldosIniciales[posicion];
    }

    public double consultarSaldoInicial(String divisa) {
        int posicion = buscarPosicion(divisa);
        if (posicion == -1) {
            throw new IllegalArgumentException("Divisa no reconocida: " + divisa);
        }
        return saldosIniciales[posicion];
    }
}
