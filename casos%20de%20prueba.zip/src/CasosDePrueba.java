import modelo.*;

/* Pruebas de los casos 11, 12 y 14 del proyecto. */
public class CasosDePrueba {

    public static void main(String[] args) {
        System.out.println("======================================");
        System.out.println(" PRUEBAS - DIVISASEGURA");
        System.out.println("======================================");

        caso11();
        caso12();
        caso14();

        System.out.println("\nPruebas finalizadas.");
    }

    // Caso 11: mismo monto para los tres tipos de cliente.
    public static void caso11() {
        System.out.println("\nCASO 11 - COMISIONES POR TIPO DE CLIENTE");

        double montoDestino = 1_000_000.0;

        Cliente general = new ClienteGeneral("C001", "Laura Gomez");
        Cliente preferencial = new ClientePreferencial("C002", "Carlos Ruiz");
        Cliente empresarial = new ClienteEmpresarial(
                "C003", "Textiles del Valle SAS", "900123456-7");

        double comisionGeneral = general.calcularComision(montoDestino);
        double comisionPreferencial = preferencial.calcularComision(montoDestino);
        double comisionEmpresarial = empresarial.calcularComision(montoDestino);

        mostrarResultado("General", comisionGeneral, 15_000.0);
        mostrarResultado("Preferencial", comisionPreferencial, 10_000.0);
        mostrarResultado("Empresarial", comisionEmpresarial, 8_000.0);
    }

    // Caso 12: validar si 100 USD cumple el mínimo de cada tipo.
    // La decisión de rechazar/aceptar una transacción se hace en la lógica
    // de negocio del sistema; aquí se prueba el mínimo que entrega cada clase.
    public static void caso12() {
        System.out.println("\nCASO 12 - MONTO MINIMO");

        Cliente empresarial = new ClienteEmpresarial(
                "C004", "Empresa Prueba", "900000000-1");
        Cliente general = new ClienteGeneral("C005", "Cliente Prueba");

        double montoEquivalenteUSD = 100.0;

        boolean empresarialCumple =
                montoEquivalenteUSD >= empresarial.getMontoMinimoUSD();
        boolean generalCumple =
                montoEquivalenteUSD >= general.getMontoMinimoUSD();

        System.out.println("Empresarial: 100 USD >= "
                + empresarial.getMontoMinimoUSD() + " USD -> "
                + (empresarialCumple ? "CUMPLE" : "NO CUMPLE")
                + " (esperado: NO CUMPLE)");

        System.out.println("General: 100 USD >= "
                + general.getMontoMinimoUSD() + " USD -> "
                + (generalCumple ? "CUMPLE" : "NO CUMPLE")
                + " (esperado: CUMPLE)");

        if (!empresarialCumple && generalCumple) {
            System.out.println("RESULTADO: CORRECTO");
        } else {
            System.out.println("RESULTADO: ERROR");
        }
    }

    // Caso 14: permisos de Cajero y Administrador.
    public static void caso14() {
        System.out.println("\nCASO 14 - PERMISOS DE EMPLEADOS");

        Empleado cajero = new Cajero("E01", "Ana Torres");
        Empleado administrador = new Administrador("E02", "Julian Mora");

        comprobar("Cajero actualiza tasas", cajero.puedeActualizarTasas(), false);
        comprobar("Administrador actualiza tasas",
                administrador.puedeActualizarTasas(), true);
        comprobar("Cajero cierra turno", cajero.puedeCerrarTurno(), false);
        comprobar("Administrador cierra turno",
                administrador.puedeCerrarTurno(), true);
    }

    private static void mostrarResultado(String tipo,
                                         double obtenido,
                                         double esperado) {
        boolean correcto = Math.abs(obtenido - esperado) < 0.000001;
        System.out.println(tipo + ": obtenido = " + obtenido
                + " | esperado = " + esperado
                + " -> " + (correcto ? "CORRECTO" : "ERROR"));
    }

    private static void comprobar(String prueba,
                                  boolean obtenido,
                                  boolean esperado) {
        System.out.println(prueba + ": obtenido = " + obtenido
                + " | esperado = " + esperado
                + " -> " + (obtenido == esperado ? "CORRECTO" : "ERROR"));
    }
}
