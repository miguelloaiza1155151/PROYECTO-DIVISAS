package modelo;

public abstract class Transaccion {
    protected String id;
    protected String fechaHora;
    protected Cliente cliente;
    protected Empleado empleado;
    protected String estado;

    public Transaccion(String id, String fechaHora, Cliente cliente,
                       Empleado empleado, String estado) {
        this.id = id;
        this.fechaHora = fechaHora;
        this.cliente = cliente;
        this.empleado = empleado;
        this.estado = estado;
    }

    public String getId() {
        return id;
    }

    public String getFechaHora() {
        return fechaHora;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public Empleado getEmpleado() {
        return empleado;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public abstract double getMontoEquivalenteCOP();

    public abstract boolean esEfectiva();

    public abstract String toLinea();

    public String mostrarDetalle() {
        return "ID: " + id
                + " | Fecha: " + fechaHora
                + " | Cliente: " + cliente.getNombre()
                + " | Empleado: " + empleado.getNombre()
                + " | Estado: " + estado;
    }
}
