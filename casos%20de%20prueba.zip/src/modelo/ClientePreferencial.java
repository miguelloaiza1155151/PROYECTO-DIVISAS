package modelo;

public class ClientePreferencial extends Cliente {

    public ClientePreferencial(String id, String nombre) {
        super(id, nombre);
    }

    @Override
    public double getPorcentajeComision() {
        return 0.010;
    }

    @Override
    public double getMontoMinimoUSD() {
        return 10.0;
    }

    @Override
    public String getTipo() {
        return "PREFERENCIAL";
    }

    @Override
    public boolean esPreferencial() {
        return true;
    }
}
