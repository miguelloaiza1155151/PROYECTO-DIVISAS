package modelo;

public class Cajero extends Empleado {

    public Cajero(String id, String nombre) {
        super(id, nombre);
    }

    @Override
    public String getRol() {
        return "CAJERO";
    }
}
