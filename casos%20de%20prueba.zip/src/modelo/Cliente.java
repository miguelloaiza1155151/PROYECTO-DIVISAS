package modelo;

public abstract class Cliente extends Persona {
    protected int operacionesRealizadas;

    public Cliente(String id, String nombre) {
        super(id, nombre);
        operacionesRealizadas = 0;
    }

    public abstract double getPorcentajeComision();

    public abstract double getMontoMinimoUSD();

    public abstract String getTipo();

    public double calcularComision(double montoDestino) {
        return montoDestino * getPorcentajeComision();
    }

    public boolean cumpleMontoMinimo(double montoEquivalenteUSD) {
        return montoEquivalenteUSD >= getMontoMinimoUSD();
    }

    public boolean esPreferencial() {
        return false;
    }

    public void registrarOperacion() {
        operacionesRealizadas++;
    }

    public int getOperacionesRealizadas() {
        return operacionesRealizadas;
    }

    @Override
    public String getRol() {
        return "CLIENTE";
    }
}
