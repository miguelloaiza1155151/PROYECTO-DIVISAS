package modelo;

public class Reversion extends Transaccion {
    private String idOriginal;
    private String motivo;

    public Reversion(String id, String fechaHora, Cliente cliente,
                     Empleado empleado, String idOriginal, String motivo) {
        super(id, fechaHora, cliente, empleado, "REVERSADA");
        this.idOriginal = idOriginal;
        this.motivo = motivo;
    }

    public String getIdOriginal() {
        return idOriginal;
    }

    public String getMotivo() {
        return motivo;
    }

    @Override
    public double getMontoEquivalenteCOP() {
        return 0.0;
    }

    @Override
    public boolean esEfectiva() {
        return false;
    }

    @Override
    public String toLinea() {
        return "REVERSION;" + id + ";" + fechaHora + ";"
                + cliente.getId() + ";" + empleado.getId() + ";"
                + idOriginal + ";" + motivo;
    }
}
