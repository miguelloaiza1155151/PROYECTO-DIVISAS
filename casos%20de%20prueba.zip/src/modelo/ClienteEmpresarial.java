package modelo;

public class ClienteEmpresarial extends Cliente {
    private String nit;

    public ClienteEmpresarial(String id, String nombre, String nit) {
        super(id, nombre);
        this.nit = nit;
    }

    public String getNit() {
        return nit;
    }

    public void setNit(String nit) {
        this.nit = nit;
    }

    @Override
    public double getPorcentajeComision() {
        return 0.008;
    }

    @Override
    public double getMontoMinimoUSD() {
        return 500.0;
    }

    @Override
    public String getTipo() {
        return "EMPRESARIAL";
    }
}
